package com.geektech.kotlin1

object Constants {
     const val KEY1 = "key1"
     const val KEY_BACK = "keyBack"

}